<?php include ('header.php')?>

<img src="logo.png" class="imghome" alt="Logo">

<!-- <h3 class="hometitel">Welkom bij De Kruidenier</h3> -->


<div id="wrapper">
    <div id="container">
    <marquee width="100%" direction="left" height="200px">
        <h2><br>Welkom bij De Kruidenier</h2>
        </marquee>
        <h3>Succes met werken :)<br><br>
                Voor vragen neem <br>
                contact op met de Teamleider</h3>
    </div>
</div>




