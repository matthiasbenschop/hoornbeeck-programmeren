<?php include 'header.php'; ?>

<?php

$id = $_GET['id'];
$sql = "SELECT * FROM images WHERE house_id='$id'";
$results = mysqli_query($conn, $sql);
while ($data = mysqli_fetch_assoc($results)) {
    echo '<img class="imagedetail" src="image/' . $data['path'] . '">';
}
?>







<?php include 'footer.php'; ?>